#include "syscall.h"

void main()
{
	Exec("../test/testfiles",17);
}