#include "syscall.h"

void main()
{

Print_Stmt("Hi"); 
Exec("../test/customer-d", 18);

}
