#include "syscall.h"

void main()
{

  /* Exec("../test/customer-d", 18);  */
  Exec("../test/customer-d", 18);
 Exec("../test/customer-d", 18); 
  Exec("../test/customer-d", 18);
 Exec("../test/customer-d", 18); 
  Exec("../test/ordertaker-d", 20);

/* Exec("../test/manager-d", 17); 
Exec("../test/cook-d", 14); */

/* Exec("../test/customer-d", 18); */

/* Exec("../test/manager", 15); */
/* Exec("../test/ordertaker-d", 20);

Exec("../test/ordertaker-d", 20); */

}
