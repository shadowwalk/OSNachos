#include "syscall.h"

void main()
{

Print_Stmt("Hi"); 
Exec("../test/manager", 15);

}
